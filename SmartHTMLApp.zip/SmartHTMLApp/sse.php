<?php
// sse.php

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: *');

// Simulate dynamic data (e.g., live quotes, alerts)
$time = date('Y-m-d H:i:s');
echo "data: Server time: {$time}\n\n";
flush();
?>
