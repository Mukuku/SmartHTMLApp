// worker.js - Web Worker script
self.onmessage = function(event) {
    const num = event.data;
    const result = num * num;
    self.postMessage(`Square of ${num} is ${result}`);
  };
  