// Geolocation API
function getLocation() {
  const output = document.getElementById("location");
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      position => {
        output.innerText = `Latitude: ${position.coords.latitude}, Longitude: ${position.coords.longitude}`;
      },
      () => {
        output.innerText = "Permission denied or location unavailable.";
      }
    );
  } else {
    output.innerText = "Geolocation is not supported by this browser.";
  }
}

// Drag and Drop API
function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  const data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}

// Web Storage API
function saveToStorage() {
  const value = document.getElementById("storage-input").value;
  localStorage.setItem("userNote", value);
  // Show the saved value immediately
  document.getElementById("storage").innerText = value;
}

function loadFromStorage() {
  const stored = localStorage.getItem("userNote");
  document.getElementById("storage").innerText = stored || "No saved note.";
  // Also update the input field with the saved value
  if (stored) {
    document.getElementById("storage-input").value = stored;
  }
}

// Web Workers API
let worker;
function startWorker() {
  if (typeof (Worker) !== "undefined") {
    if (!worker) {
      worker = new Worker("workers.js");
    }
    worker.onmessage = function (event) {
      document.getElementById("worker-result").innerText = event.data;
    };
    const input = prompt("Enter a number to square:");
    if (!isNaN(input)) {
      worker.postMessage(Number(input));
    }
  } else {
    document.getElementById("worker-result").innerText = "Web Workers not supported.";
  }
}

// Server-Sent Events (SSE)
if (!!window.EventSource) {
  const source = new EventSource("sse.php");
  source.onmessage = function (event) {
    const msgBox = document.getElementById("sse-messages");
    msgBox.innerHTML += `<p>${event.data}</p>`;
  };
} else {
  document.getElementById("sse-messages").innerText = "SSE not supported by this browser.";
}

// Optional: Theme Toggle with localStorage
function toggleTheme() {
  const body = document.body;
  body.classList.toggle("dark");
  localStorage.setItem("theme", body.classList.contains("dark") ? "dark" : "light");
}

// Live Clock - Update every second
function updateClock() {
  const clockElement = document.getElementById("live-clock");
  const now = new Date();
  clockElement.innerText = now.toLocaleTimeString();
}

// Start the clock immediately and update it every second
setInterval(updateClock, 1000);

// Apply saved theme and load saved note on load
window.onload = () => {
  if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark");
  }
  // Load saved note automatically
  loadFromStorage();
};
